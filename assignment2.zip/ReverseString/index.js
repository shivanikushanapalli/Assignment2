function reverseString() {
    //input value
    const userInput = document.getElementById("userInput").value;
    
    //Reverse the string
    const reversedString = userInput.split("").reverse().join("");
    
    //Result
    document.getElementById("result").textContent = `Reversed String: ${reversedString}`;
  }
  