function checkPalindrome() {
    // input
    const numberInput = document.getElementById("numberInput").value;
    
    // remove non numeric characters
    const cleanedInput = numberInput.replace(/[^0-9]/g, '');
  
    // input empty or not
    if (cleanedInput === "") {
      document.getElementById("result").textContent = "Please enter a valid series of numbers.";
      return;
    }
  
    // palindrome or not
    const isPalindrome = cleanedInput === cleanedInput.split("").reverse().join("");
    
    // Result
    if (isPalindrome) {
      document.getElementById("result").textContent = "It's a palindrome!";
    } else {
      document.getElementById("result").textContent = "Not a palindrome.";
    }
  }
  