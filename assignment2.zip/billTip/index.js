function calculateTotal() {
    //  The subtotal and tip values
    const subtotal = parseFloat(document.getElementById("subtotal").value);
    const tipPercentage = parseFloat(document.getElementById("tipPercentage").value);
  
    // check if the input is valid or not
    if (isNaN(subtotal) || subtotal < 0) {
      document.getElementById("result").textContent = "enter a valid subtotal amount.";
      return;
    }
  
    if (isNaN(tipPercentage) || tipPercentage < 0) {
      document.getElementById("result").textContent = "enter a valid tip percentage.";
      return;
    }
  
    // Tip and Total calculation
    const tipAmount = (subtotal * tipPercentage) / 100;
    const totalAmount = subtotal + tipAmount;
  
    // Result
    document.getElementById("result").textContent = `Total to be paid (including tip): $${totalAmount.toFixed(2)}`;
  }
  